package com.example.stalkeriptv

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity:AppCompatActivity(){
    private var player:ExoPlayer?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_player)
        val v=findViewById<PlayerView>(R.id.playerView)
        val u=intent.getStringExtra("url")?:run{finish();return}
        player=ExoPlayer.Builder(this).build().also{v.player=it;it.setMediaItem(MediaItem.fromUri(Uri.parse(u)));it.prepare();it.playWhenReady=true}
    }
    override fun onStop(){player?.release();player=null;super.onStop()}
}
