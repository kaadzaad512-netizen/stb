package com.example.stalkeriptv

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity:AppCompatActivity() {
    private lateinit var portal:EditText; private lateinit var mac:EditText
    private lateinit var connect:Button; private lateinit var search:EditText
    private lateinit var status:TextView; private lateinit var list:RecyclerView
    private var client:StalkerClient?=null; private var channels=emptyList<Channel>()
    private lateinit var adapter:Adapter

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        portal=findViewById(R.id.portalInput); mac=findViewById(R.id.macInput)
        connect=findViewById(R.id.connectButton); search=findViewById(R.id.searchInput)
        status=findViewById(R.id.statusText); list=findViewById(R.id.channelList)
        list.layoutManager=LinearLayoutManager(this)
        adapter=Adapter(emptyList()){play(it)}; list.adapter=adapter
        connect.setOnClickListener{connectPortal()}
        search.setOnEditorActionListener{_,_,_->filter(search.text.toString());false}
    }

    private fun connectPortal() {
        val p=portal.text.toString().trim(); val m=mac.text.toString().trim()
        if(p.isBlank()||m.isBlank()){Toast.makeText(this,"Enter portal and MAC",Toast.LENGTH_SHORT).show();return}
        connect.isEnabled=false; status.text="Connecting…"
        lifecycleScope.launch {
            try {
                val r=withContext(Dispatchers.IO){
                    val c=StalkerClient(p,m); c.handshake(); c.getProfile(); c.getMainInfo(); c to c.getChannels()
                }
                client=r.first; channels=r.second; adapter.setItems(channels)
                search.visibility=View.VISIBLE; status.text="Connected — ${channels.size} channels"
            } catch(e:Exception) { status.text="Connection failed: ${e.message?: "unknown error"}" }
            finally { connect.isEnabled=true }
        }
    }

    private fun filter(q0:String) {
        val q=q0.trim().lowercase()
        adapter.setItems(if(q.isBlank()) channels else channels.filter{it.name.lowercase().contains(q)||it.number.orEmpty().contains(q)})
    }

    private fun play(ch:Channel) {
        val c=client?:return; status.text="Opening ${ch.name}…"
        lifecycleScope.launch {
            try {
                val url=withContext(Dispatchers.IO){c.createLink(ch.id)}
                startActivity(Intent(this@MainActivity,PlayerActivity::class.java).putExtra("url",url).putExtra("name",ch.name))
            } catch(e:Exception) { status.text="Playback link failed: ${e.message?: "unknown error"}" }
        }
    }

    private class Adapter(private var items:List<Channel>,val click:(Channel)->Unit):RecyclerView.Adapter<Adapter.VH>() {
        class VH(v:View):RecyclerView.ViewHolder(v){val name:TextView=v.findViewById(R.id.channelName);val meta:TextView=v.findViewById(R.id.channelMeta)}
        override fun onCreateViewHolder(p:android.view.ViewGroup,t:Int)=VH(LayoutInflater.from(p.context).inflate(R.layout.item_channel,p,false))
        override fun onBindViewHolder(h:VH,i:Int){val c=items[i];h.name.text=c.name;h.meta.text=listOfNotNull(c.number,c.genreId?.let{"genre $it"}).joinToString(" • ");h.itemView.setOnClickListener{click(c)}}
        override fun getItemCount()=items.size
        fun setItems(x:List<Channel>){items=x;notifyDataSetChanged()}
    }
}
