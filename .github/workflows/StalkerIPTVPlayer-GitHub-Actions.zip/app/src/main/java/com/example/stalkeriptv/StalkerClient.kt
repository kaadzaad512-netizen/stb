package com.example.stalkeriptv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Channel(val id:String, val name:String, val number:String?, val genreId:String?)

class StalkerClient(portalInput:String, private val mac:String) {
    private val client = OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).build()
    private val portal = portalInput.trim().trimEnd('/')
    private var token:String? = null

    private fun base():String = when {
        portal.endsWith("/stalker_portal") -> "$portal/server/load.php"
        portal.endsWith("/server/load.php") -> portal
        portal.endsWith("/portal.php") -> portal
        else -> "$portal/stalker_portal/server/load.php"
    }

    private fun call(params:Map<String,String>):JSONObject {
        val q=params.entries.joinToString("&") {
            "${URLEncoder.encode(it.key,"UTF-8")}=${URLEncoder.encode(it.value,"UTF-8")}"
        }
        val b=Request.Builder().url("${base()}?$q")
            .header("User-Agent","Mozilla/5.0 (Android) Stalker IPTV Player")
            .header("X-User-Agent","Model: MAG250; Link: WiFi")
            .header("Cookie","mac=$mac; stb_lang=en; timezone=GMT")
        token?.let { b.header("Authorization","Bearer $it") }
        client.newCall(b.build()).execute().use { r ->
            if(!r.isSuccessful) error("HTTP ${r.code}")
            return JSONObject(r.body?.string()?:"{}")
        }
    }

    fun handshake():String {
        val js=call(mapOf("type" to "stb","action" to "handshake","token" to "","mac" to mac,"JsHttpRequest" to "1-xml"))
            .optJSONObject("js") ?: error("Handshake response missing js")
        token=js.optString("token").takeIf { it.isNotBlank() } ?: error("Portal did not return a token")
        return token!!
    }

    fun getProfile()=call(mapOf("type" to "stb","action" to "get_profile","JsHttpRequest" to "1-xml"))
    fun getMainInfo()=call(mapOf("type" to "account_info","action" to "get_main_info","JsHttpRequest" to "1-xml"))
    fun getGenres():JSONArray=call(mapOf("type" to "itv","action" to "get_genres","JsHttpRequest" to "1-xml")).optJSONArray("js")?:JSONArray()

    fun getChannels():List<Channel> {
        val js=call(mapOf("type" to "itv","action" to "get_all_channels","JsHttpRequest" to "1-xml")).optJSONObject("js")
        val data=js?.optJSONArray("data")?:JSONArray()
        return buildList {
            for(i in 0 until data.length()) {
                val x=data.optJSONObject(i)?:continue
                val id=x.optString("id"); if(id.isBlank()) continue
                add(Channel(id,x.optString("name","Channel $id"),x.optString("number").takeIf{it.isNotBlank()},x.optString("tv_genre_id").takeIf{it.isNotBlank()}))
            }
        }
    }

    fun createLink(channelId:String):String {
        val js=call(mapOf("type" to "itv","action" to "create_link",
            "cmd" to "ffmpeg http://localhost/ch/$channelId","JsHttpRequest" to "1-xml")).optJSONObject("js")
            ?:error("create_link returned no js")
        var cmd=js.optString("cmd").trim()
        if(cmd.isBlank()) error("Portal returned an empty stream URL")
        listOf("ffmpeg ","vlc ","http ").forEach { p -> if(cmd.startsWith(p,true)) cmd=cmd.substring(p.length).trim() }
        return cmd
    }
}
