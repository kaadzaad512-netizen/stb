package com.example.progtv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class Channel(val name: String, val url: String)

class MainActivity : ComponentActivity() {
    private val channels = listOf(
        Channel("Demo Channel 1", "https://example.com/stream.m3u8"),
        Channel("Demo Channel 2", "https://example.com/stream2.m3u8")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ProgTVScreen(channels) } }
    }
}

@Composable
fun ProgTVScreen(channels: List<Channel>) {
    var selected by remember { mutableStateOf<Channel?>(null) }

    Row(Modifier.fillMaxSize().background(Color(0xFF101010))) {
        LazyColumn(
            Modifier.width(280.dp).fillMaxHeight().background(Color(0xFF181818))
        ) {
            item {
                Text(
                    "PROG TV",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(20.dp)
                )
            }
            items(channels) { channel ->
                Text(
                    channel.name,
                    color = Color.White,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selected = channel }
                        .padding(18.dp)
                )
            }
        }

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (selected == null) {
                Text("Select a channel", color = Color.White)
            } else {
                VideoPlayer(selected!!.url, Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
fun VideoPlayer(url: String, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply {
            this.player = player
            useController = true
        }},
        modifier = modifier
    )
}
