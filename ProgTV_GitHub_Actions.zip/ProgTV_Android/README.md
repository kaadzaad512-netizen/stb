# ProgTV Android + GitHub Actions

This is a starter Android IPTV player using Kotlin, Jetpack Compose and Media3/ExoPlayer.

## Build an APK from your phone using GitHub

1. Create a new GitHub repository.
2. Upload the contents of this project (not the ZIP file itself).
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build ProgTV APK**.
6. Tap **Run workflow** if it is not automatically running.
7. When the workflow finishes, open the completed run.
8. Under **Artifacts**, download `ProgTV-debug-apk`.
9. Extract the downloaded artifact and install `app-debug.apk`.

The current channels are demo URLs. Replace them with IPTV streams you are authorized to access.

The workflow builds a real APK containing compiled DEX/resources; simply renaming a source ZIP to `.apk` is not equivalent.
